package com.example.usingsensor_decoupling_detection;

import android.util.Log;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class StoreFunc {

    private FileWriter fw;
    private BufferedWriter bw;

    StoreFunc() {
    }


    void store_senor(ArrayList<ValueStorage> datalist, String name, String filepath) throws IOException {
        if(datalist == null || datalist.size() == 0)
            return;

        int datalen = datalist.get(0).getSize();

        long now = System.currentTimeMillis();
        Date d = new Date(now);
        SimpleDateFormat sd = new SimpleDateFormat("yyyy-MM-dd-hh-mm-ss");
        String time = sd.format(d);

        Log.e("store", time);

        File file = new File(filepath+"/"+time+" "+name+" .csv");

        if(!file.exists()){
            file.createNewFile();
        }

        fw = new FileWriter(file.getAbsoluteFile());
        bw = new BufferedWriter(fw);

        System.out.println(name + " datasize : " + datalen);

        for(int i = 0 ; i <datalist.size(); i++){
            System.out.println(i+"번째 데이터 저장 완료");
            bw.write(String.valueOf(datalist.get(i).getTime()));
            for (int j = 0 ; j<datalen; j++) {
                bw.write(","+String.valueOf(datalist.get(i).getValue()[j]));
            }
            System.out.println("");
            bw.newLine();
        }
        bw.close();
        fw.close();

        datalist.clear();
    }
}
