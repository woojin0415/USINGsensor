package com.example.usingsensor_decoupling_detection;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface comm {

    //GET 방식의 데이터 전송
    @FormUrlEncoded
    @POST("usingsesnor/usingsensor/")
    Call<String> acc_data(
            @Field("x_all") String x_all,
            @Field("y_all") String y_all,
            @Field("z_all") String z_all,
            @Field("x") String x_list,
            @Field("y") String y_list,
            @Field("z") String z_list,
            @Field("mode") String mode);

    @GET("usingsesnor/delete/")
    Call<String> delete();

}
