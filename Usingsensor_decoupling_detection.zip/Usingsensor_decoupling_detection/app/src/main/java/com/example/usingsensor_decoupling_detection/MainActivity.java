package com.example.usingsensor_decoupling_detection;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.converter.scalars.ScalarsConverterFactory;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ArrayList<ValueStorage> datalist_acc = new ArrayList<>();
        StoreFunc store = new StoreFunc();

        Button bt = findViewById(R.id.bt_start);
        Button bt_stop = findViewById(R.id.bt_stop);

        TextView tv = findViewById(R.id.tv);

        //Using the Gyroscope & Accelometer
        SensorManager sm = (SensorManager) getSystemService(Context.SENSOR_SERVICE);


        Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        Ringtone ringtone = RingtoneManager.getRingtone(getApplicationContext(),notification);

        //Using the Accelometer
        Sensor mAccelometerSensor = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        AccelerationSensor acc = new AccelerationSensor(mAccelometerSensor, sm, datalist_acc, ringtone, tv);

        File sensor_dir = new File(Environment.getExternalStorageDirectory().getAbsoluteFile() + "/usingsensordata");
        if(!sensor_dir.exists()){
            sensor_dir.mkdir();
        }



        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                acc.start();
            }
        });

        bt_stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tv.setText("Store");
                acc.stop();
                try {
                    Log.e("store", "store");
                    store.store_senor(datalist_acc, "acc", Environment.getExternalStorageDirectory() + "/usingsensordata");
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        });




    }
}