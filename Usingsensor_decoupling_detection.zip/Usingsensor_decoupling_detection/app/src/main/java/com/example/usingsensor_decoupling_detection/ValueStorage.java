package com.example.usingsensor_decoupling_detection;

public class ValueStorage {
    private float[] value;
    private int size;
    private long time;

    ValueStorage(int size){
        this.size = size;
        value = new float[size];
    }

    public float[] getValue() {
        return value;
    }
    public int getSize(){ return size;}
    public long getTime(){return time;}


    public void setValue(float[] value, long time) {
        this.value = value;
        this.time = time;
    }

}



