package com.example.usingsensor_decoupling_detection;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.Ringtone;
import android.os.Environment;
import android.util.Log;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.File;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.converter.scalars.ScalarsConverterFactory;

public class AccelerationSensor extends AppCompatActivity {
    private SEL acl;
    private SensorManager SM;
    private Sensor Acc;
    private int datalen;
    private int counter;
    private boolean decouple;
    TextView tv;

    private float[] buffer_z = new float[100];
    private float[] buffer_y = new float[100];
    private float[] buffer_x = new float[100];
    private long pre_now;


    private ValueStorage vs;
    private ArrayList<ValueStorage> datalist;
    private String filepath;


    Ringtone rt;

    private Retrofit retrofit;



    AccelerationSensor(Sensor sensor, SensorManager SM, ArrayList<ValueStorage> datalist, Ringtone rt, TextView tv) {
        Acc = sensor;
        this.SM = SM;
        acl = new SEL();
        for(int i =0; i< buffer_z.length; i++){
            buffer_z[i] = 0;
            buffer_y[i] = 0;
            buffer_y[i] = 0;
        }
        this.rt = rt;
        this.tv = tv;
        this.datalist = datalist;
        setRetrofitInit();
        decouple = false;

        filepath = Environment.getExternalStorageDirectory() +"/usingsensordata";

        File dir = new File(filepath);
        dir.mkdir();

    }

    private void setRetrofitInit () {
        Gson gson = new GsonBuilder().setLenient().create();
        retrofit = new Retrofit.Builder()
                .baseUrl("http://203.255.81.72:10021/")
                .addConverterFactory(ScalarsConverterFactory.create())
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();
    }

    public void start() {
        tv.setText("");
        pre_now = 0;
        counter = 0;
        SM.registerListener(acl, Acc, SM.SENSOR_DELAY_UI);

    }

    public void stop() {
        SM.unregisterListener(acl);

    }

    private class SEL implements SensorEventListener {
        @Override
        public void onSensorChanged(SensorEvent event) {

            Log.e("sensor", "센싱중");
            long now = System.currentTimeMillis();
            if(pre_now != now ) {
                pre_now = now;


                datalen = event.values.length;

                float[] storage = new float[datalen];

                vs = new ValueStorage(event.values.length);
                for (int i = 0; i < event.values.length; i++) {
                    storage[i] = event.values[i];
                }
                vs.setValue(storage, now);
                datalist.add(vs);




                float x = event.values[0];
                float y = event.values[1];
                float z = event.values[2];

                buffer_add(x, y, z);

                //Log.e("test", String.valueOf(z));

                counter += 1;


                if(counter % 30 == 0){
                    String x_all = print_list(buffer_x, 0, buffer_x.length - 1);
                    String y_all = print_list(buffer_y, 0, buffer_y.length - 1);
                    String z_all = print_list(buffer_z, 0, buffer_z.length - 1);

                    String x_list = print_list(buffer_x, buffer_x.length-30, buffer_x.length);
                    String y_list = print_list(buffer_y, buffer_y.length-30, buffer_y.length);
                    String z_list = print_list(buffer_z, buffer_z.length-30, buffer_z.length);
                    comm service = retrofit.create(comm.class);

                    Call<String> call = null;
                    call = service.acc_data(x_all, y_all, z_all, x_list, y_list, z_list, "monitor");

                    call.enqueue(new Callback<String>() {
                        @Override
                        public void onResponse(Call<String> call, Response<String> response) {
                            if(response.body().toString().equals("decouple")) {
                                decouple = true;
                                tv.setText("Decouple");
                                if(!decouple) {
                                    rt.play();
                                }
                            }
                            if(response.body().toString().equals("couple")) {
                                decouple = false;
                                tv.setText("Couple");
                                rt.stop();
                            }
                        }

                        @Override
                        public void onFailure(Call<String> call, Throwable t) {

                        }
                    });
                }

                if (counter >= buffer_z.length) {
                    int index = check_action();

                    Log.e("test", String.valueOf(index));

                    if (index != -1) {
                        if (index > 60) {
                            counter = 60;
                        } else {
                            String x_all = print_list(buffer_x, 0, buffer_x.length - 1);
                            String y_all = print_list(buffer_y, 0, buffer_y.length - 1);
                            String z_all = print_list(buffer_z, 0, buffer_z.length - 1);

                            String x_list = print_list(buffer_x, index, index + 30);
                            String y_list = print_list(buffer_y, index, index + 30);
                            String z_list = print_list(buffer_z, index, index + 30);
                            //Log.e("test11", String.valueOf(buffer[0]) + "/" +String.valueOf(buffer[1]));
                            Log.e("tt", z_list);

                            counter = 0;

                            comm service = retrofit.create(comm.class);

                            Call<String> call = null;
                            call = service.acc_data(x_all, y_all, z_all, x_list, y_list, z_list, "detector");


                            call.enqueue(new Callback<String>() {
                                @Override
                                public void onResponse(Call<String> call, Response<String> response) {
                                    if(response.body().toString().equals("decouple")) {
                                        decouple = true;
                                        tv.setText("Decouple");
                                        if(decouple) {
                                            rt.play();
                                        }
                                    }
                                    if(response.body().toString().equals("couple")) {
                                        decouple = false;
                                        tv.setText("Couple");
                                        rt.stop();
                                    }
                                }

                                @Override
                                public void onFailure(Call<String> call, Throwable t) {

                                }
                            });
                            //stop();
                        }
                    } else {
                        counter = 50;
                    }


                }
            }



        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {

        }
    }

    private void buffer_add(float x, float y, float z){
        for(int i = 0; i < buffer_z.length - 1; i++){
            buffer_z[i] = buffer_z[i+1];
        }
        buffer_z[buffer_z.length-1] = z;

        for(int i = 0; i < buffer_y.length - 1; i++){
            buffer_y[i] = buffer_y[i+1];
        }
        buffer_y[buffer_y.length-1] = y;

        for(int i = 0; i < buffer_x.length - 1; i++){
            buffer_x[i] = buffer_x[i+1];
        }
        buffer_x[buffer_x.length-1] = x;
    }

    private int check_action(){
        boolean detect = false;
        int index = -1;
        int detect_range = 20;
        float max = 0;
        for(int i =0; i< buffer_z.length - 30; i++){
            if (Math.abs(buffer_z[i] - buffer_z[i+detect_range]) > 3 && buffer_z[i] != 0 && buffer_z[i+detect_range] != 0){
                if (max < Math.abs(buffer_z[i] - buffer_z[i+detect_range])){
                    detect = true;
                    max = Math.abs(buffer_z[i] - buffer_z[i+detect_range]);
                    index = i;

                }
            }
        }
        return index;

    }

    private String print_list(float arr[], int start, int end){
        String str = "[";

        for (int i =start; i <end; i++){
            if (i != end-1) {
                str += String.valueOf(arr[i]) + ", ";
            }
            else{
                str += String.valueOf(arr[i]);
            }
        }

        str += "]";
        return str;
    }
}

